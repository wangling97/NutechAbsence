package com.example.nutechapps.retrofit.interfaces.auth;

public interface TokenCallback {
    void onResponse(boolean status);
}
